#!/usr/bin python2.7
# -*- coding: utf-8 -*-

import requests

r = requests.get('http://cn.python-requests.org/en/latest/')
r.encoding